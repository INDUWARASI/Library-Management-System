package controller;

import dao.BookDAO;
import model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "BookServlet", urlPatterns = {"/BookServlet", "/addBook"})
public class BookServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("search.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        if ("/addBook".equals(path)) {
            String title = request.getParameter("title");
            String author = request.getParameter("author");

            Book book = new Book();
            
            book.setTitle(title);
            book.setAuthor(author);
            book.setStatus("Available");

            BookDAO dao = new BookDAO();
            dao.addBook(book);

            response.sendRedirect("dashboard.jsp");
        } else {

            String title = request.getParameter("title");

            BookDAO bookDAO = new BookDAO();
            List<Book> bookList = bookDAO.searchBooks(title);

            request.setAttribute("bookList", bookList);
            request.getRequestDispatcher("bookList.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Handles book search and forwarding to book list page";
    }
}
