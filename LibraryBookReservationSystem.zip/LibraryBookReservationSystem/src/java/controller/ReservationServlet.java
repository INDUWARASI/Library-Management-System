package controller;

import dao.BookDAO;
import dao.ReservationDAO;
import model.Book;
import model.Reservation;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

@WebServlet(name = "ReservationServlet", urlPatterns = {"/ReservationServlet"})
public class ReservationServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ReservationDAO DAO = new ReservationDAO();
        List<Reservation> reservationList = DAO.getReservationHistory();

        request.setAttribute("reservationList", reservationList);
        request.getRequestDispatcher("viewReservation.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentName = request.getParameter("studentName");
        String studentId = request.getParameter("studentId");
        int bookId = Integer.parseInt(request.getParameter("bookId"));

        BookDAO bookDAO = new BookDAO();
        Book book = bookDAO.getBookById(bookId);  // Check book status

        if (book != null && !"reserved".equalsIgnoreCase(book.getStatus())) {
            // Proceed with reservation
            Timestamp reservationDate = new Timestamp(System.currentTimeMillis());

            Reservation reservation = new Reservation();
            reservation.setStudentName(studentName);
            reservation.setStudentId(studentId);
            reservation.setBookId(bookId);
            reservation.setReservationDate(reservationDate);

            ReservationDAO reservationDAO = new ReservationDAO();
            reservationDAO.reserveBook(reservation);
            bookDAO.updateBookStatus(bookId, "reserved");

            response.sendRedirect("success.jsp");

        } else {
            // Book already reserved or not found
            request.setAttribute("errorMessage", "Sorry, this book has already been reserved.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Handles book reservation requests";
    }
}
