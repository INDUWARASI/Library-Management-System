package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Book;

public class BookDAO {
    private final String jdbcURL = "jdbc:mysql://localhost:3306/librarydb";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "";

    public BookDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            if (jdbcConnection != null) {
                System.out.println("Connection to the database was successful!");
                jdbcConnection.close();
            } else {
                System.out.println("Failed to make connection to the database.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }

    public List<Book> searchBooks(String title) {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE title LIKE ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + title + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Book book = new Book(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("status")
                );
                books.add(book);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return books;
    }

    public Book getBookById(int id) {
        Book book = null;
        String sql = "SELECT * FROM books WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                book = new Book(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("status")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return book;
    }

    public void updateBookStatus(int bookId, String status) {
        String sql = "UPDATE books SET status = ? WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setInt(2, bookId);
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Book status updated successfully.");
            } else {
                System.out.println("No book found with the given ID.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public boolean addBook(Book book) {
        String sql = "INSERT INTO books (title, author) VALUES (?, ?)";

        // Database connection and statement
        try (Connection conn = getConnection(); 
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            // Set the title and author as parameters in the prepared statement
            preparedStatement.setString(1, book.getTitle());
            preparedStatement.setString(2, book.getAuthor());

            // Execute the update to insert the book into the database
            int rowsAffected = preparedStatement.executeUpdate();

            // If one row was affected, the book was added successfully
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();  // Handle SQL exceptions, you may want to log this in a real app
        }

        // Return false if the book could not be added
        return false;
    }
}

