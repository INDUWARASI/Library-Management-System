package dao;

import model.Reservation;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

public class ReservationDAO {

    private final String jdbcURL = "jdbc:mysql://localhost:3306/librarydb";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "";

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }

    public void reserveBook(Reservation reservation) {
        String sql = "INSERT INTO reservations (student_name, student_id, book_id, reservation_date) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, reservation.getStudentName());
            stmt.setString(2, reservation.getStudentId());
            stmt.setInt(3, reservation.getBookId());
            stmt.setTimestamp(4, reservation.getReservationDate());

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Book reserved successfully!");
            } else {
                System.out.println("Failed to reserve the book.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
     public List<Reservation> getReservationHistory() {
    List<Reservation> reservationList = new ArrayList<>();

    String sql = "SELECT * FROM reservations";

    try (Connection conn = getConnection(); 
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Reservation res = new Reservation();
            res.setStudentName(rs.getString("student_name"));
            res.setStudentId(rs.getString("student_id"));
            res.setBookId(rs.getInt("book_id"));
            res.setReservationDate(rs.getTimestamp("reservation_date"));
            reservationList.add(res);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return reservationList;
}
    
}

